from dotenv import load_dotenv
from .paths import INSTANCE_DIR, PROJECT_ROOT

load_dotenv(PROJECT_ROOT / ".env")

from flask import (
    Flask, abort, render_template, request, send_file, redirect,
    url_for, jsonify, Response, send_from_directory
)
from .comparador import (
    comparar,
    TOTAL_LOJAS,
)
from .gerar_pdf import gerar_pdf
from .scrapers.driver_manager import pre_aquecer
from .models import db
import os
import json
import re
import secrets
import time
import threading
import unicodedata
from datetime import datetime
from statistics import median

from flask_login import LoginManager, current_user
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect
from .auth_routes import auth_bp, limiter
from .models import Usuario

INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
app = Flask(__name__, instance_path=str(INSTANCE_DIR), instance_relative_config=True)

app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get(
    "DATABASE_URL", "sqlite:///orcatech.db"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["TESTING"] = os.environ.get("TESTING") == "1"
app.config["DEBUG"] = os.environ.get("FLASK_DEBUG", "").lower() in {"1", "true", "yes"}
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("APP_ENV", "").lower() in {
    "production", "prod"
}
app.config["RATELIMIT_STORAGE_URI"] = os.environ.get(
    "RATELIMIT_STORAGE_URI", "memory://"
)

secret_key = os.environ.get("SECRET_KEY")
if not secret_key:
    if not app.config["TESTING"]:
        raise RuntimeError("A variável SECRET_KEY deve estar definida no arquivo .env.")
    secret_key = "testing-only-secret-key"
app.config["SECRET_KEY"] = secret_key

db.init_app(app)
csrf = CSRFProtect(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = "auth.login"
limiter.init_app(app)


@login_manager.user_loader
def carregar_usuario(usuario_id):
    usuario = db.session.get(Usuario, int(usuario_id))
    return usuario if usuario and usuario.ativo else None


@app.before_request
def exigir_login():
    if request.endpoint in {"static", "favicon", "auth.login", "auth.logout"}:
        return None
    if not current_user.is_authenticated:
        return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
    return None


@app.after_request
def adicionar_cabecalhos_seguranca(response):
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' data: https://fonts.gstatic.com; "
        "img-src 'self' data: https:; "
        "connect-src 'self'; "
        "object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    )
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    return response


app.register_blueprint(auth_bp)
from .orcamento_routes import orcamento_bp
app.register_blueprint(orcamento_bp)
from .fornecedores_routes import fornecedores_bp
app.register_blueprint(fornecedores_bp)

@app.route('/favicon.ico')
def favicon():
    """Ícone da aba do navegador (vale para todas as páginas, mesmo sem <link> no template)."""
    return send_from_directory(os.path.join(app.root_path, 'static', 'favicon'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')


from .paths import HISTORICO_FILE

_jobs = {}
_jobs_lock = threading.Lock()


def ler_historico():
    if not os.path.exists(HISTORICO_FILE):
        return []
    with open(HISTORICO_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def salvar_historico(produto, produtos):
    historico = ler_historico()
    validos = [p for p in produtos if p.get("preco", 0) > 0]
    if not validos:
        return
    mais_barato = min(validos, key=lambda x: x["preco"])
    premium     = max(validos, key=lambda x: x["preco"])
    economia    = economia_mesmo_modelo(validos)
    historico.append({
        "data": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "produto": produto,
        "total": len(produtos),
        "mais_barato_nome":  mais_barato["nome"][:50],
        "mais_barato_preco": mais_barato["preco_texto"],
        "mais_barato_site":  mais_barato["site"],
        "premium_nome":  premium["nome"][:50],
        "premium_preco": premium["preco_texto"],
        "premium_site":  premium["site"],
        "economia": f"R$ {economia:,.2f}".replace(',','X').replace('.',',').replace('X','.')
    })
    with open(HISTORICO_FILE, "w", encoding="utf-8") as f:
        json.dump(historico, f, ensure_ascii=False, indent=2)


def economia_mesmo_modelo(produtos):
    grupos = {}
    cores = {
        'preto', 'preta', 'branco', 'branca', 'azul', 'verde', 'cinza',
        'dourado', 'dourada', 'prata', 'roxo', 'rosa',
    }
    for produto in produtos:
        nome = unicodedata.normalize('NFD', produto.get('nome', '').lower())
        nome = ''.join(c for c in nome if unicodedata.category(c) != 'Mn')
        chave = tuple(
            token for token in re.findall(r'\w+', nome)
            if token not in cores
        )
        preco = produto.get('preco', 0)
        if chave and preco > 0:
            grupos.setdefault(chave, []).append(preco)

    economias = [
        median(precos) - min(precos)
        for precos in grupos.values()
        if len(precos) > 1
    ]
    return round(max(economias, default=0), 2)


def ultima_pesquisa():
    historico = ler_historico()
    return historico[-1] if historico else None


def _parse_valor_brl(texto):
    """Converte 'R$ 7.735,19' -> 7735.19. Usado para reconstruir números
    a partir dos valores já formatados que ficam salvos no historico.json."""
    try:
        s = re.sub(r'[^\d,.]', '', str(texto))
        if not s:
            return 0.0
        if ',' in s and '.' in s:
            s = s.replace('.', '').replace(',', '.')
        elif ',' in s:
            s = s.replace(',', '.')
        return float(s)
    except Exception:
        return 0.0


def _worker(job_id, produto, forcar):
    with _jobs_lock:
        _jobs[job_id]["status"] = "running"
        job_ref = _jobs[job_id]

    try:
        resultado = comparar(
            produto,
            forcar_busca=forcar,
            job=job_ref,
        )
        salvar_historico(produto, resultado["produtos"])
        with _jobs_lock:
            _jobs[job_id]["status"] = "done"
            _jobs[job_id]["resultado"] = resultado

    except Exception as e:
        with _jobs_lock:
            _jobs[job_id]["status"] = "error"
            _jobs[job_id]["erro"] = str(e)


@app.route('/')
def home():
    ultima    = ultima_pesquisa()
    historico = ler_historico()
    return render_template('index.html', ultima=ultima, historico=historico)


@app.route('/buscar', methods=['POST'])
def buscar():
    produto     = request.form.get('produto', '').strip() or 'tecnologia'
    solicitante = current_user.nome
    forcar      = request.form.get('forcar_busca') == '1'

    job_id = secrets.token_urlsafe(12)

    lojas_base = {
        "mercadolivre": {"status": "pending", "count": 0},
        "kabum":        {"status": "pending", "count": 0},
        "amazon":       {"status": "pending", "count": 0},
        "terabyte":     {"status": "pending", "count": 0},
        "americanas":   {"status": "pending", "count": 0},
        "ibyte":        {"status": "pending", "count": 0},
        "gshield":      {"status": "pending", "count": 0},
        "aliexpress":   {"status": "pending", "count": 0},
    }

    _jobs[job_id] = {
        "status": "pending",
        "usuario_id": current_user.id,
        "produto": produto,
        "solicitante": solicitante,
        "resultado": None,
        "progresso": 0,
        "lojas": lojas_base,
        "produtos_encontrados": 0,
    }

    t = threading.Thread(
        target=_worker,
        args=(job_id, produto, forcar),
        daemon=True
    )
    t.start()

    return redirect(url_for('aguardando', job_id=job_id, solicitante=solicitante))


@app.route('/aguardando/<job_id>')
def aguardando(job_id):
    with _jobs_lock:
        job = _jobs.get(job_id)
    if not job or job["usuario_id"] != current_user.id:
        abort(404)
    return render_template('aguardando.html',
                           job_id=job_id,
                           produto=job['produto'],
                           solicitante=current_user.nome)


@app.route('/status/<job_id>')
def status(job_id):
    """
    Retorna status completo do job incluindo progresso por loja.
    Mantido para compatibilidade — o aguardando.html deve passar a usar
    /stream/<job_id> (Server-Sent Events), mas esse endpoint continua
    funcionando como fallback via polling se precisar.
    """
    with _jobs_lock:
        job = _jobs.get(job_id)
    if not job or job["usuario_id"] != current_user.id:
        abort(404)

    return jsonify({
        "status": job["status"],
        "progresso": job.get("progresso", 0),
        "lojas": job.get("lojas", {}),
        "produtos_encontrados": job.get("produtos_encontrados", 0)
    })


@app.route('/progresso/<job_id>')
def progresso(job_id):
    """Alias mantido para compatibilidade retroativa."""
    return status(job_id)


@app.route('/stream/<job_id>')
def stream(job_id):
    """
    Server-Sent Events: empurra o status do job para o navegador assim que
    ele muda, em vez do front ficar perguntando (polling) a cada X segundos.
    O cliente consome com `new EventSource('/stream/<job_id>')`.
    """
    with _jobs_lock:
        job = _jobs.get(job_id)
    if not job or job["usuario_id"] != current_user.id:
        abort(404)

    def gerar():
        ultimo_estado = None
        tentativas_sem_job = 0

        while True:
            with _jobs_lock:
                job = _jobs.get(job_id)

            if not job:
                tentativas_sem_job += 1
                # Job pode ainda não ter sido registrado por uma fração de
                # segundo (corrida entre o redirect e a thread). Só desiste
                # de fato depois de algumas tentativas.
                if tentativas_sem_job > 5:
                    yield f"data: {json.dumps({'status': 'not_found'})}\n\n"
                    break
                time.sleep(0.3)
                continue

            estado = {
                "status": job.get("status", "pending"),
                "progresso": job.get("progresso", 0),
                "lojas": job.get("lojas", {}),
                "produtos_encontrados": job.get("produtos_encontrados", 0),
            }

            if estado != ultimo_estado:
                yield f"data: {json.dumps(estado)}\n\n"
                ultimo_estado = estado

            if estado["status"] in ("done", "error"):
                break

            time.sleep(0.6)

    resp = Response(gerar(), mimetype="text/event-stream")
    resp.headers["Cache-Control"] = "no-cache"
    resp.headers["X-Accel-Buffering"] = "no"  # evita buffer se houver nginx na frente
    resp.headers["Connection"] = "keep-alive"
    return resp


@app.route('/resultado/<job_id>')
def resultado(job_id):
    with _jobs_lock:
        job = _jobs.get(job_id)
    if not job or job["usuario_id"] != current_user.id:
        abort(404)
    if job["status"] != "done":
        return redirect(url_for('aguardando', job_id=job_id))
    res = job["resultado"]
    return render_template('resultados.html',
                           produto=res['produto'],
                           solicitante=current_user.nome,
                           produtos=res['produtos'],
                           do_cache=res['do_cache'])


@app.route('/orcamentos')
def orcamentos():
    historico = ler_historico()
    orcamentos_view = []
    for i, item in enumerate(historico):
        item_com_id = dict(item)
        item_com_id['id'] = i
        orcamentos_view.append(item_com_id)
    orcamentos_view.reverse()  # mais recentes primeiro
    with _jobs_lock:
        jobs_ativos = {
            jid: j for jid, j in _jobs.items()
            if j["usuario_id"] == current_user.id
            and j["status"] in ("pending", "running")
        }
    return render_template('orcamentos.html', orcamentos=orcamentos_view, jobs_ativos=jobs_ativos)


@app.route('/relatorios')
def relatorios():
    historico = ler_historico()
    total_cotacoes = len(historico)
    economias = [_parse_valor_brl(h.get('economia', '0')) for h in historico]
    economia_total = f"{sum(economias):,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
    return render_template('relatorios.html', historico=historico, total_lojas=TOTAL_LOJAS,
                           total_cotacoes=total_cotacoes, economia_total=economia_total)


@app.route('/api/relatorios_dados')
def relatorios_dados():
    """
    Dados agregados do historico.json prontos para alimentar gráficos
    (Chart.js ou similar) na página de relatórios: economia acumulada,
    lojas mais baratas e produtos mais pesquisados.
    """
    historico = ler_historico()
    if not historico:
        return jsonify({"vazio": True})

    economias = [_parse_valor_brl(h.get("economia", "0")) for h in historico]

    economia_acumulada = []
    soma = 0.0
    for e in economias:
        soma += e
        economia_acumulada.append(round(soma, 2))

    contagem_lojas = {}
    for h in historico:
        loja = h.get("mais_barato_site") or "—"
        contagem_lojas[loja] = contagem_lojas.get(loja, 0) + 1

    contagem_produtos = {}
    for h in historico:
        p = (h.get("produto") or "—").strip().lower()
        contagem_produtos[p] = contagem_produtos.get(p, 0) + 1
    top_produtos = sorted(contagem_produtos.items(), key=lambda kv: -kv[1])[:8]

    return jsonify({
        "vazio": False,
        "total_buscas":   len(historico),
        "economia_total": round(sum(economias), 2),
        "economia_media": round(sum(economias) / len(economias), 2) if economias else 0,
        "labels":             [h.get("produto", "—")[:24] for h in historico],
        "datas":              [h.get("data", "") for h in historico],
        "economias":          economias,
        "economia_acumulada": economia_acumulada,
        "lojas_mais_baratas": contagem_lojas,
        "top_produtos": [{"produto": p, "vezes": v} for p, v in top_produtos],
    })


@app.route('/rever/<int:indice>')
def rever(indice):
    historico = ler_historico()
    if indice < 0 or indice >= len(historico):
        return redirect(url_for('orcamentos'))
    item    = historico[indice]
    produto = item['produto']
    resultado = comparar(produto, forcar_busca=False)
    return render_template('resultados.html',
                           produto=produto,
                           solicitante='',
                           produtos=resultado['produtos'],
                           do_cache=resultado['do_cache'])


@app.route('/gerar_pdf', methods=['POST'])
def baixar_pdf():
    produto     = request.form.get('produto', 'produto')
    solicitante = request.form.get('solicitante', '')
    resultado   = comparar(produto)
    caminho_pdf = gerar_pdf(produto, resultado['produtos'], solicitante)
    return send_file(caminho_pdf, as_attachment=True,
                     download_name=os.path.basename(caminho_pdf),
                     mimetype='application/pdf')


@app.route('/gerar_pdf_historico/<int:indice>', methods=['GET', 'POST'])
def gerar_pdf_historico(indice):
    historico = ler_historico()
    if indice < 0 or indice >= len(historico):
        return redirect(url_for('orcamentos'))
    item        = historico[indice]
    produto     = item['produto']
    solicitante = request.form.get('solicitante', '')
    resultado   = comparar(produto, forcar_busca=False)
    caminho_pdf = gerar_pdf(produto, resultado['produtos'], solicitante)
    return send_file(caminho_pdf, as_attachment=True,
                     download_name=os.path.basename(caminho_pdf),
                     mimetype='application/pdf')


if __name__ == '__main__':
    print("✓ OrçaTech iniciado")

    # NÃO chame pre_aquecer() aqui — abre uma janela Chrome visível à toa.
    # O ChromeDriver é baixado automaticamente na primeira busca real.

    app.run(debug=app.config["DEBUG"], use_reloader=False, threaded=True)