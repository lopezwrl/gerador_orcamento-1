"""Testes automatizados do OrçaTech."""
